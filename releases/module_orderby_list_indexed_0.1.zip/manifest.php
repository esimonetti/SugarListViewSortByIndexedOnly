<?php
$manifest = array (
  'id' => 'orderby_list_indexed_0.1',
  'built_in_version' => '7.9.1.0',
  'name' => 'Order by indexed fields on listviews',
  'description' => 'Order by indexed fields on listviews',
  'version' => '0.1',
  'author' => 'Enrico Simonetti, SugarCRM Inc.',
  'is_uninstallable' => true,
  'published_date' => '2017-08-21 06:42:33',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Accounts/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/clients/base/views/list/removesort-list.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Accounts/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Accounts/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Accounts/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Bugs/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Bugs/Ext/clients/base/views/list/removesort-list.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Bugs/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Bugs/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Bugs/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Bugs/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Calls/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Calls/Ext/clients/base/views/list/removesort-list.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Calls/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Calls/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Calls/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Calls/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Campaigns/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Campaigns/Ext/clients/base/views/list/removesort-list.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Campaigns/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Campaigns/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Campaigns/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Campaigns/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Cases/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Cases/Ext/clients/base/views/list/removesort-list.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Cases/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Cases/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Cases/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Cases/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/clients/base/views/list/removesort-list.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contacts/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contracts/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Contracts/Ext/clients/base/views/list/removesort-list.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contracts/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Contracts/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    20 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Contracts/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Contracts/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    21 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Documents/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Documents/Ext/clients/base/views/list/removesort-list.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Documents/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Documents/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    23 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Documents/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Documents/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Emails/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Emails/Ext/clients/base/views/list/removesort-list.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Emails/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Emails/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    26 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Emails/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Emails/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    27 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/EmailTemplates/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/EmailTemplates/Ext/clients/base/views/list/removesort-list.php',
    ),
    28 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/EmailTemplates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/EmailTemplates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    29 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/EmailTemplates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/EmailTemplates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    30 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/EmbeddedFiles/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/EmbeddedFiles/Ext/clients/base/views/list/removesort-list.php',
    ),
    31 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/EmbeddedFiles/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/EmbeddedFiles/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    32 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/EmbeddedFiles/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/EmbeddedFiles/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    33 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Employees/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Employees/Ext/clients/base/views/list/removesort-list.php',
    ),
    34 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Employees/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Employees/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    35 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Employees/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Employees/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    36 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ForecastManagerWorksheets/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ForecastManagerWorksheets/Ext/clients/base/views/list/removesort-list.php',
    ),
    37 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ForecastManagerWorksheets/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ForecastManagerWorksheets/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    38 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ForecastManagerWorksheets/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ForecastManagerWorksheets/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    39 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ForecastWorksheets/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ForecastWorksheets/Ext/clients/base/views/list/removesort-list.php',
    ),
    40 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ForecastWorksheets/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ForecastWorksheets/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    41 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ForecastWorksheets/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ForecastWorksheets/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    42 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBContents/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/KBContents/Ext/clients/base/views/list/removesort-list.php',
    ),
    43 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBContents/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/KBContents/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    44 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBContents/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/KBContents/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    45 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBContentTemplates/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/KBContentTemplates/Ext/clients/base/views/list/removesort-list.php',
    ),
    46 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBContentTemplates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/KBContentTemplates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    47 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBContentTemplates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/KBContentTemplates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    48 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBDocuments/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/KBDocuments/Ext/clients/base/views/list/removesort-list.php',
    ),
    49 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBDocuments/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/KBDocuments/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    50 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/KBDocuments/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/KBDocuments/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    51 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Leads/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/views/list/removesort-list.php',
    ),
    52 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Leads/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    53 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Leads/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    54 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Meetings/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Meetings/Ext/clients/base/views/list/removesort-list.php',
    ),
    55 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Meetings/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Meetings/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    56 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Meetings/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Meetings/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    57 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Notes/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Notes/Ext/clients/base/views/list/removesort-list.php',
    ),
    58 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Notes/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Notes/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    59 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Notes/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Notes/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    60 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Notifications/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Notifications/Ext/clients/base/views/list/removesort-list.php',
    ),
    61 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Notifications/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Notifications/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    62 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Notifications/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Notifications/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    63 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Opportunities/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/clients/base/views/list/removesort-list.php',
    ),
    64 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Opportunities/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    65 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Opportunities/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    66 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Business_Rules/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/pmse_Business_Rules/Ext/clients/base/views/list/removesort-list.php',
    ),
    67 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Business_Rules/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/pmse_Business_Rules/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    68 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Business_Rules/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/pmse_Business_Rules/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    69 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Emails_Templates/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/pmse_Emails_Templates/Ext/clients/base/views/list/removesort-list.php',
    ),
    70 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Emails_Templates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/pmse_Emails_Templates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    71 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Emails_Templates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/pmse_Emails_Templates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    72 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Inbox/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/pmse_Inbox/Ext/clients/base/views/list/removesort-list.php',
    ),
    73 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Inbox/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/pmse_Inbox/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    74 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Inbox/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/pmse_Inbox/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    75 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Project/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/pmse_Project/Ext/clients/base/views/list/removesort-list.php',
    ),
    76 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Project/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/pmse_Project/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    77 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/pmse_Project/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/pmse_Project/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    78 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductCategories/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ProductCategories/Ext/clients/base/views/list/removesort-list.php',
    ),
    79 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductCategories/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ProductCategories/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    80 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductCategories/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ProductCategories/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    81 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Products/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Products/Ext/clients/base/views/list/removesort-list.php',
    ),
    82 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Products/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Products/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    83 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Products/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Products/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    84 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductTemplates/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ProductTemplates/Ext/clients/base/views/list/removesort-list.php',
    ),
    85 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductTemplates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ProductTemplates/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    86 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductTemplates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ProductTemplates/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    87 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductTypes/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ProductTypes/Ext/clients/base/views/list/removesort-list.php',
    ),
    88 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductTypes/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ProductTypes/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    89 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProductTypes/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ProductTypes/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    90 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Project/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Project/Ext/clients/base/views/list/removesort-list.php',
    ),
    91 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Project/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Project/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    92 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Project/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Project/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    93 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProjectTask/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ProjectTask/Ext/clients/base/views/list/removesort-list.php',
    ),
    94 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProjectTask/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ProjectTask/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    95 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProjectTask/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ProjectTask/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    96 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProspectLists/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/ProspectLists/Ext/clients/base/views/list/removesort-list.php',
    ),
    97 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProspectLists/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/ProspectLists/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    98 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/ProspectLists/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/ProspectLists/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    99 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Prospects/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Prospects/Ext/clients/base/views/list/removesort-list.php',
    ),
    100 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Prospects/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Prospects/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    101 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Prospects/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Prospects/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    102 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Quotes/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Quotes/Ext/clients/base/views/list/removesort-list.php',
    ),
    103 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Quotes/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Quotes/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    104 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Quotes/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Quotes/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    105 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Reports/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Reports/Ext/clients/base/views/list/removesort-list.php',
    ),
    106 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Reports/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Reports/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    107 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Reports/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Reports/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    108 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/RevenueLineItems/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/RevenueLineItems/Ext/clients/base/views/list/removesort-list.php',
    ),
    109 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/RevenueLineItems/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/RevenueLineItems/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    110 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/RevenueLineItems/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/RevenueLineItems/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    111 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Styleguide/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Styleguide/Ext/clients/base/views/list/removesort-list.php',
    ),
    112 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Styleguide/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Styleguide/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    113 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Styleguide/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Styleguide/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    114 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Tags/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Tags/Ext/clients/base/views/list/removesort-list.php',
    ),
    115 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Tags/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Tags/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    116 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Tags/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Tags/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    117 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Tasks/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Tasks/Ext/clients/base/views/list/removesort-list.php',
    ),
    118 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Tasks/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Tasks/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    119 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Tasks/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Tasks/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    120 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Teams/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Teams/Ext/clients/base/views/list/removesort-list.php',
    ),
    121 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Teams/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Teams/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    122 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Teams/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Teams/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    123 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Users/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/Users/Ext/clients/base/views/list/removesort-list.php',
    ),
    124 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Users/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/Users/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    125 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Users/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/Users/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    126 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/UserSignatures/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/UserSignatures/Ext/clients/base/views/list/removesort-list.php',
    ),
    127 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/UserSignatures/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/UserSignatures/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    128 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/UserSignatures/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/UserSignatures/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    129 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/WebLogicHooks/Ext/clients/base/views/list/removesort-list.php',
      'to' => 'custom/Extension/modules/WebLogicHooks/Ext/clients/base/views/list/removesort-list.php',
    ),
    130 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/WebLogicHooks/Ext/clients/base/views/selection-list/removesort-selection-list.php',
      'to' => 'custom/Extension/modules/WebLogicHooks/Ext/clients/base/views/selection-list/removesort-selection-list.php',
    ),
    131 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/WebLogicHooks/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
      'to' => 'custom/Extension/modules/WebLogicHooks/Ext/clients/base/views/subpanel-list/removesort-subpanel-list.php',
    ),
    132 => 
    array (
      'from' => '<basepath>/custom/include/indexFinder.php',
      'to' => 'custom/include/indexFinder.php',
    ),
  ),
);
